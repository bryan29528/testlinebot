from django.apps import AppConfig


class BotappConfig(AppConfig):
    name = 'botapp'
